// src/component/StatusCard.js
import React from 'react';
import './StatusCard.css';

const StatusCard = () => {
  return (
    <div className="status-card">
    </div>
  );
};

export default StatusCard;
